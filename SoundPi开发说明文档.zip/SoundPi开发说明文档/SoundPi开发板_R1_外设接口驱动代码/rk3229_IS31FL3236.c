#include <linux/device.h>
#include <linux/i2c.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/gpio.h>
#include <linux/irq.h>
#include <linux/ioc4.h>
#include <linux/io.h>
#include <linux/proc_fs.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <asm/uaccess.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <linux/wait.h>
#include <linux/slab.h>
#include <linux/of_gpio.h>
#include <asm/atomic.h>
#include <linux/semaphore.h>

struct is31fl3236 
{
	u8	channels;					/*gpio�ĸ���*/
	u8	shutdown_reg;				/*Shutdown Register�ĵ�ַ*/
	u8	pwm_update_reg;				/*pwm_update_reg�ĵ�ַ��������Ĵ���д0���ɽ�pwm_register�е����ý���Ӧ��*/
	u8	global_control_reg;			/*ȫ��ʹ�ܼĴ�����ַ��д0��set all channels enable*/
	u8	reset_reg;					/*Reset all registers into default value*/
	u8	pwm_register_base;			/*����pwm�ļĴ����Ļ���ַ*/
	u8	led_control_register_base;	/*ʹ��ͨ���ļĴ�������ַ*/
	int sdb_gpio;					/*����gpio����͵�ƽ��оƬ��Դ���ر�*/
	bool sdb_gpio_level;
	int (*reset_func)(struct is31fl3236 *priv);
	int (*sw_shutdown_func)(struct is31fl3236 *priv, bool enable);
	struct i2c_client *client;
	struct mutex mutex;/*������*/
};
#define IS31FL3236SHUTDOWN_SSD_ENABLE  		0
#define IS31FL3236_SHUTDOWN_SSD_DISABLE   (1<<0)
/* Used to indicate a device has no such register */
#define IS31FL3236_REG_NONE 				0xFF



static struct is31fl3236 is31fl3236_chip = {
	.channels					= 30,			/*��36������ʵ����ֻ�õ���30��(OUT1-OUT30)*/		
	.shutdown_reg				= 0x00,		
	.pwm_update_reg				= 0x25,
	.global_control_reg			= 0x4a,
	.reset_reg					= 0x4f,
	.pwm_register_base			= 0x01,
	.led_control_register_base	= 0x26,
	.sdb_gpio					= -1,
};

static struct class  *is31fl3236_class   = NULL;
static struct device *is31fl3236_device  = NULL;
static atomic_t can_open = ATOMIC_INIT(1);/*����һ��ԭ�ӱ���������ʼ��Ϊ1*/




static int is31fl3236_write_reg(struct is31fl3236 *priv, u8 reg, u8 val)
{
	int ret = -1;

	//printk(KERN_INFO "writing register 0x%02X=0x%02X", reg, val);

	ret =  i2c_smbus_write_byte_data(priv->client, reg, val);
	if (ret) 
	{
		dev_err(&priv->client->dev, "register write to 0x%02X failed (error %d)", reg, ret);
	}
	
	return ret;
}

/*ʹ�ܻ�ر�оƬ*/
static int is31fl3236_software_shutdown(struct is31fl3236 *priv, bool enable)
{
	u8 value = enable ? IS31FL3236SHUTDOWN_SSD_ENABLE : IS31FL3236_SHUTDOWN_SSD_DISABLE;

	return is31fl3236_write_reg(priv, priv->shutdown_reg, value);
}


static int is31fl3236_reset(struct is31fl3236 *priv)
{
	return is31fl3236_write_reg(priv, priv->reset_reg, 0x0);
}

static int is31fl3236_update(struct is31fl3236 *priv)
{
	return is31fl3236_write_reg(priv, priv->pwm_update_reg, 0x0);
}

#if 0
static unsigned int LedOrder(unsigned int led) 
{
  static const int kAllLedGreen3229Complement = 0x09249249;
  return (led & kAllLedGreen3229Complement)
      | ((led & kAllLedGreen3229Complement << 1) << 1)
      | ((led & kAllLedGreen3229Complement << 2) >> 1);
}


static int is31fl3236_set_led(struct is31fl3236 *priv, unsigned int *data)
{
    unsigned int led = LedOrder(*data);
    int i = 0;

    for(i = 0; i < priv->channels; i++)
    {
        if(((led)>>i) & 0x00000001)
        {
                is31fl3236_write_reg(priv, priv->led_control_register_base+i, (1<<0));
        }
        else
        {
                is31fl3236_write_reg(priv, priv->led_control_register_base+i, 0x0);
        }
    }
    is31fl3236_update(priv);

   	return 0;
}
#endif


#if 1
/*������ر�ĳ��ͨ�������*/
static int is31fl3236_set_led(struct is31fl3236 *priv, unsigned int *data)
{
	int i = 0;

	//printk(KERN_INFO "is31fl3236_set_led data = 0x%02x\n", *data);
	for(i = 0; i < priv->channels; i++)
	{
		if(((*data)>>i) & 0x00000001)
		{
			/*�ر�led*/
			if(i % 3 == 0)
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+i, 0);
			}
			else if((i-1) % 3 == 0)
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+i+1, 0);
			}
			else
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+i-1, 0);
			}
		}
		else
		{
			/*����led*/
			if(i % 3 == 0)
			{
				//printk(KERN_INFO "Light LED Green = 0x%x\n", priv->led_control_register_base+i);
				is31fl3236_write_reg(priv, priv->led_control_register_base+i, (1<<0));
			}
			else if((i-1) % 3 == 0)
			{
				//printk(KERN_INFO "Light LED Blue = 0x%x\n", priv->led_control_register_base+i+1);
				is31fl3236_write_reg(priv, priv->led_control_register_base+i+1, (1<<0));
			}
			else
			{
				//printk(KERN_INFO "Light LED Red = 0x%x\n", priv->led_control_register_base+i-1);
				is31fl3236_write_reg(priv, priv->led_control_register_base+i-1, (1<<0));
			}
		}
	}
	is31fl3236_update(priv);

	return 0;
}
#endif
static int is31fl3236_init_regs(struct is31fl3236 *priv)
{
	int ret = -1;

	/*��λоƬ*/
	ret = priv->reset_func(priv);
	if (ret)
	{
		printk(KERN_INFO "reset is31fl3236 failed ret = %d\n", ret);
		return ret;
	}
	
	/*�������е�led��IOUT = IMAX*/
	if (priv->led_control_register_base != IS31FL3236_REG_NONE) 
	{
		
		u8 num_regs = priv->channels;
		int i;
		for (i = 0; i < num_regs; i++) 
		{
			ret = is31fl3236_write_reg(priv, priv->led_control_register_base+i, (1<<0));
			if (ret)
				return ret;
		}
	}
	
	/*�����е�pwm�������Ϊ���ֵ*/
	if (priv->pwm_register_base != IS31FL3236_REG_NONE)
	{
		u8 num_regs = priv->channels;
		int i;
		for (i = 0; i < num_regs; i++) 
		{
			ret = is31fl3236_write_reg(priv, priv->pwm_register_base+i, 0xFF);
			if (ret)
				return ret;
		}
	}
	/*��������*/
	ret = is31fl3236_update(priv);
	if(ret)
	{
		printk(KERN_INFO "update is31fl3236 failed ret = %d\n", ret);
		return ret;		
	}
	
	/*ʹ��оƬ*/
	if(priv->sw_shutdown_func != NULL)
	{
		ret = priv->sw_shutdown_func(priv, false);
		if (ret)
		{
			printk(KERN_INFO "Enable Chip Failed\n");
			return ret;
		}
	}
	
	/*ʹ��ȫ��ͨ��*/ 
	if (priv->global_control_reg != IS31FL3236_REG_NONE)
	{
		ret = is31fl3236_write_reg(priv, priv->global_control_reg, 0x00);
		if (ret)
		{
			printk(KERN_INFO "Enable Chip All Channel Failed\n");
			return ret;
		}
	}

	return 0;
}


static int is31fl3236_open(struct inode *inode, struct file *file)
{
	//int ret = -1;
	
	/*��֧����������������ʣ�Ҳ��֧���첽�źţ����ɶ�δ�*/
	if(!atomic_dec_and_test(&can_open))/*�Լ���������Ϊ0�򷵻�ture*/
	{
		atomic_dec(&can_open);/*ȫ��ʹ��ԭ�Ӳ�����ֹ�ڴ��ڴ��иն����Ĵ����л�δд��ʱ�ͱ�����*/
		return -EBUSY;
	}
	/*ret = is31fl3236_reset(&is31fl3236_chip);
	if(ret)
	{
		printk(KERN_INFO "please cheak if [is31fl3236] exists? \n");
		return -EINVAL;
	}*/
		
	return 0;
}
static int led_flag = 4;

static ssize_t is31fl3236_read(struct file *file, char __user *ubuf, size_t len, loff_t *loff)
{

	printk(KERN_WARNING "This is is31fl3236 _read nothing to do led_flag=%d\n",led_flag);

	return 0;
}

static int dt_input = 0;
static int ota_counter = 1;
static ssize_t is31fl3236_write(struct file *file, const char __user *ubuf, size_t len, loff_t *loff)
{
	int ret = -1;
	u8 buf[4];
	
	memset(buf, 0, sizeof(buf));
	printk("\n is31fl3236 _write len =%d \n",len);
	if(len >= sizeof(buf))/*�ж�Ҫд��������Ƿ񳬳���Χ�����һ��ֻ����д4���ֽڳ��ȵ�����*/
	{
		printk(KERN_INFO "the write value byte must equal = 4\n");
	}
	if(copy_from_user(buf, ubuf, sizeof(buf)))/*�����ݸ��Ƶ��ں˿ռ�*/
	{
		printk(KERN_INFO "copy_from_user failed\n");
		return -EFAULT;
	}
	//printk(KERN_INFO "buf[0] = 0x%x\n", buf[0]);
	//printk(KERN_INFO "buf[1] = 0x%x\n", buf[1]);
	//printk(KERN_INFO "buf[2] = 0x%x\n", buf[2]);
	//printk(KERN_INFO "buf[3] = 0x%x\n", buf[3]);
	mutex_lock(&is31fl3236_chip.mutex);
	/*����is31fl3236���е��*/
	//add
	if(len==1||len==2)
	{
		printk("\n buf[0] =%d \n",buf[0]);
		switch (buf[0]) {
			case 0x30:
				led_flag = 0;
				break;
			case 0x31:
				led_flag = 1;
				break;
			case 0x32:
				led_flag = 2;
				break;
			case 0x33:
				led_flag = 3;
				break;
			case 0x34:
				led_flag = 4;
				ota_counter = buf[1]-0x30;
				if(ota_counter!=0&&ota_counter!=1)
					ota_counter=1;
				break;
			case 0x35:
				led_flag = 5;
				dt_input = buf[1]-0x30;
				if(dt_input<0&&dt_input>10)
					dt_input=0;
				break;
			case 0x36:
				led_flag = 6;
				break;
			default:
				break;
			}
		printk("\n led_flag = %d \n",led_flag);
	}
	else
	{
		is31fl3236_set_led(&is31fl3236_chip, (unsigned int*)buf);
	}
	mutex_unlock(&is31fl3236_chip.mutex);

	return ret;
}

static int is31fl3236_close(struct inode *inode, struct file *file)
{
	
	printk(KERN_WARNING "This is is31fl3236_close\n");
	atomic_inc(&can_open);
	
	return 0;
}


static struct file_operations is31fl3236_fops = 
{
	.owner		  	= THIS_MODULE,
	.open		  	= is31fl3236_open,
	.read		 	= is31fl3236_read,
	.write		  	= is31fl3236_write,
	.release	  	= is31fl3236_close,
};

#if 1

static int ledon(struct is31fl3236 * priv ,int color)
{
	int i = 0;
	int red = 0;
	int green = 0;
	int blue = 0;
	u8 num_regs = priv->channels;

	if(color == 0) ;
	else if(color == 1) red = (1<<0);
	else if(color == 2) green = (1<<0);
	else if(color == 3) blue = (1<<0);
	
	for (i = 0; i < num_regs; i++) 
	{
		if(i % 3 == 0)
		{
			is31fl3236_write_reg(priv, priv->led_control_register_base+i, green);
		}
		else if((i-1) % 3 == 0)
		{
			is31fl3236_write_reg(priv, priv->led_control_register_base+i, red);
		}
		else
		{
			is31fl3236_write_reg(priv, priv->led_control_register_base+i, blue);
		}
	}
	/*��������*/
	is31fl3236_update(priv);

	return 0;
}

static int __ref led_thread(void *data) 
{
	struct is31fl3236 *priv = data;
	int counter = 0; // 0 direction
 	int i = 0;
	//int ret = -1;
	u8 num_regs = priv->channels;
	printk("\n yanjunan led_thread %d \n",num_regs);
	while(1)
	{
		/*���ض���pwm�������Ϊ��ɫ*/
		if(led_flag==4) //start red green led
		{
			i = counter%num_regs;
			/*����led*/
			if(i % 3 == 0)
			{
				//printk(KERN_INFO "Light LED Green = 0x%x\n", priv->led_control_register_base+i);
				is31fl3236_write_reg(priv, priv->led_control_register_base+i, 1);  // green led off
				is31fl3236_write_reg(priv, priv->led_control_register_base+i+1, 0); // red led off
				is31fl3236_write_reg(priv, priv->led_control_register_base+i+2, 0); // blue led on
				if(i==0) 
				{
					is31fl3236_write_reg(priv, priv->led_control_register_base+27, 0); 
					is31fl3236_write_reg(priv, priv->led_control_register_base+28, ota_counter); // red led on
				}
				else
				{
					is31fl3236_write_reg(priv, priv->led_control_register_base+i-3, 0);
					is31fl3236_write_reg(priv, priv->led_control_register_base+i-2,ota_counter); // red led on
				}
				/*��������*/
				is31fl3236_update(priv);
			}

		}

		if(led_flag==5) // direction select
		{
			counter = 3*dt_input;
			printk("\n dt_input=%d \n",dt_input);
			is31fl3236_write_reg(priv, priv->led_control_register_base+counter, (1<<0));  // green led off
			if(counter==0)
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+27, (1<<0));
				is31fl3236_write_reg(priv, priv->led_control_register_base+3, (1<<0)); 
			}
			else if(counter==27)
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+24, (1<<0));
				is31fl3236_write_reg(priv, priv->led_control_register_base+0, (1<<0)); 
			}
			else
			{
				is31fl3236_write_reg(priv, priv->led_control_register_base+counter-3, (1<<0));
				is31fl3236_write_reg(priv, priv->led_control_register_base+counter+3, (1<<0)); 
			}
			/*��������*/
			is31fl3236_update(priv);
			led_flag = 44;
		}
		
		// ota green on
		if(led_flag==6) //start green led
		{
			i = counter % num_regs;
			/*����led*/
			if(i % 3 == 0)
			{
				if(counter % 2 ==0)
				{
					ledon(priv,2);
				}
				else
				{
					ledon(priv,0);
				}

			}

		}

		if(led_flag>=0&&led_flag<4) // all led off
		{
			ledon(priv,led_flag);
			led_flag = 44;
		}
		
		msleep(100);
		counter++;
		if(counter >= 150)
		{
			counter = 0;
		}
		
	}
	return 0;
}
#endif

static int major = -1;
static int is31fl3236_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int ret = -1;
	struct is31fl3236 *priv = &is31fl3236_chip;
	enum of_gpio_flags flags;
		
	priv->client = client;
	mutex_init(&priv->mutex);
	i2c_set_clientdata(client, priv);
	priv->sw_shutdown_func	= is31fl3236_software_shutdown;
	priv->reset_func		= is31fl3236_reset;
	
	priv->sdb_gpio = of_get_named_gpio_flags(client->dev.of_node, "gpio_en", 0, &flags);
	if (priv->sdb_gpio < 0) 
	{
		printk(KERN_INFO "of_get_named_gpio_flags sdb pin failed\n");
		priv->sdb_gpio = -1;
	}
	else
	{
		priv->sdb_gpio_level = (flags & OF_GPIO_ACTIVE_LOW)? 0:1;/*����ߵ�ƽоƬ����*/
	    ret = gpio_request(priv->sdb_gpio, "sdb_pin");
	    if (ret != 0) 
		{
		    printk("%s request sdb_pin error", __func__);
		    return ret;
	    }
	    gpio_direction_output(priv->sdb_gpio,priv->sdb_gpio_level);/*����ߵ�ƽ����оƬ�ϵ�*/
	}
	ret = is31fl3236_init_regs(priv);				/*�Ѿ��������е�led*/
	kernel_thread(led_thread, priv, CLONE_PTRACE);
	if(ret)
	{
		printk(KERN_INFO "init is31fl3236 regs failed\r\n");
		goto out3;
	}
	/*ע��һ���ַ��豸*/
	major = register_chrdev(0, "is31fl3236", &is31fl3236_fops);/*ע��һ���ַ��豸����*/
	if(major < 0)
	{
		printk(KERN_WARNING "register_chrdev is31fl3236 faild\n");
		return -1;
	}

	is31fl3236_class = class_create(THIS_MODULE,"is31fl3236");
	if(NULL ==is31fl3236_class)
	{
		printk(KERN_WARNING "class_create failed\n");
		goto out2;
	}
	is31fl3236_device = device_create(is31fl3236_class,NULL,MKDEV(major,0),NULL,"is31fl3236");
	if(NULL == is31fl3236_device)
	{
		printk(KERN_WARNING "device_create failed\n");
		goto out1;
	}
	printk(KERN_INFO "is31fl3236_probe success\n");
	
	return 0;
	
out1:
	class_destroy(is31fl3236_class);
out2:
	unregister_chrdev(major,"is31fl3236");
out3:
	gpio_free(priv->sdb_gpio);
	return -1;

}


static int is31fl3236_remove(struct i2c_client *client)
{
	struct is31fl3236 *priv = (struct is31fl3236 *)i2c_get_clientdata(client);

	if(is31fl3236_device != NULL)
		device_destroy(is31fl3236_class,MKDEV(major,0));
	if(is31fl3236_class != NULL)
		class_destroy(is31fl3236_class);
	if(major != -1)
		unregister_chrdev(major,"is31fl3236");
	if(priv->sdb_gpio != -1)
		gpio_free(priv->sdb_gpio);
	
	printk(KERN_INFO "is31fl3236_remove success\n");
	
	return 0;
}


static const struct of_device_id of_is31fl3236_match[] = {
	{ .compatible = "issi,is31fl3236"},
	{},
};

/*��ʾ����������ƥ�������*/
static const struct i2c_device_id is31fl3236_id[] = {
	{ "is31fl3236" },
	{},
};
MODULE_DEVICE_TABLE(i2c, is31fl3236_id);

static struct i2c_driver is31fl3236_driver = {
	.driver = {
		.name	= "is31fl3236",
		.of_match_table = of_match_ptr(of_is31fl3236_match),
	},
	.probe		= is31fl3236_probe,
	.remove		= is31fl3236_remove,
	.id_table	= is31fl3236_id,
};


static int __init is31fl3236_init(void)
{
	int ret = -1;
	
	printk("==is31fl3236_init==\n");
	ret = i2c_add_driver(&is31fl3236_driver);
	if(ret)
	{
		printk(KERN_INFO "i2c_add_driver failed ret = %d\n", ret);
		return -1;
	}
	return 0;
}

static void __exit is31fl3236_exit(void)
{
	printk("==is31fl3236_exit==\n");
	i2c_del_driver(&is31fl3236_driver);
}

module_init(is31fl3236_init);
module_exit(is31fl3236_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("is31fl3236 Extend GPIO driver");
MODULE_AUTHOR("He Fei GKST");
MODULE_ALIAS("char device: fl3236");


